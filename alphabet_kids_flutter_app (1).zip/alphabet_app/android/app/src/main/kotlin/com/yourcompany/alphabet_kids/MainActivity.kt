package com.yourcompany.alphabet_kids

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
