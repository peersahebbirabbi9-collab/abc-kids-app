import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/letter_data.dart';
import '../widgets/letter_card.dart';
import 'letter_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Set<String> learnedLetters = {};

  @override
  void initState() {
    super.initState();
    _loadProgress();
  }

  Future<void> _loadProgress() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      learnedLetters = (prefs.getStringList('learned') ?? []).toSet();
    });
  }

  Future<void> _markLearned(String letter) async {
    final prefs = await SharedPreferences.getInstance();
    learnedLetters.add(letter);
    await prefs.setStringList('learned', learnedLetters.toList());
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'ABC Kids 🎈',
          style: TextStyle(fontWeight: FontWeight.w900, fontSize: 26),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFF4DABF7),
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: LinearProgressIndicator(
              value: learnedLetters.length / alphabetData.length,
              minHeight: 10,
              borderRadius: BorderRadius.circular(10),
              backgroundColor: Colors.grey.shade300,
              color: Colors.greenAccent.shade700,
            ),
          ),
          Text(
            'Learned ${learnedLetters.length} of ${alphabetData.length} letters!',
            style: const TextStyle(fontSize: 14, color: Colors.black54),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: alphabetData.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1,
              ),
              itemBuilder: (context, index) {
                final data = alphabetData[index];
                return LetterCard(
                  data: data,
                  isLearned: learnedLetters.contains(data.letter),
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => LetterDetailScreen(
                          index: index,
                          onLearned: _markLearned,
                        ),
                      ),
                    );
                    _loadProgress();
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
