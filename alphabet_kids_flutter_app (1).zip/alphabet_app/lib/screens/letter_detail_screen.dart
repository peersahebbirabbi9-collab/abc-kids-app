import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:confetti/confetti.dart';
import '../models/letter_data.dart';

class LetterDetailScreen extends StatefulWidget {
  final int index;
  final Function(String letter) onLearned;

  const LetterDetailScreen({
    super.key,
    required this.index,
    required this.onLearned,
  });

  @override
  State<LetterDetailScreen> createState() => _LetterDetailScreenState();
}

class _LetterDetailScreenState extends State<LetterDetailScreen> {
  late PageController _pageController;
  late int currentIndex;
  final FlutterTts _tts = FlutterTts();
  late ConfettiController _confettiController;

  @override
  void initState() {
    super.initState();
    currentIndex = widget.index;
    _pageController = PageController(initialPage: currentIndex);
    _confettiController =
        ConfettiController(duration: const Duration(seconds: 1));
    _setupTts();
    // Speak the first letter automatically when opened.
    WidgetsBinding.instance.addPostFrameCallback((_) => _speakCurrent());
  }

  Future<void> _setupTts() async {
    await _tts.setLanguage('en-US');
    await _tts.setSpeechRate(0.4);
    await _tts.setPitch(1.1);
  }

  Future<void> _speakCurrent() async {
    final data = alphabetData[currentIndex];
    await _tts.stop();
    await _tts.speak('${data.letter}. ${data.word}');
  }

  void _onPageChanged(int index) {
    setState(() => currentIndex = index);
    widget.onLearned(alphabetData[index].letter);
    _confettiController.play();
    Future.delayed(const Duration(milliseconds: 300), _speakCurrent);
  }

  @override
  void dispose() {
    _tts.stop();
    _pageController.dispose();
    _confettiController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final data = alphabetData[currentIndex];
    return Scaffold(
      backgroundColor: data.color,
      body: SafeArea(
        child: Stack(
          alignment: Alignment.topCenter,
          children: [
            Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 4),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back,
                            color: Colors.white, size: 28),
                        onPressed: () => Navigator.pop(context),
                      ),
                      const Spacer(),
                      Text(
                        '${currentIndex + 1} / ${alphabetData.length}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(width: 16),
                    ],
                  ),
                ),
                Expanded(
                  child: PageView.builder(
                    controller: _pageController,
                    itemCount: alphabetData.length,
                    onPageChanged: _onPageChanged,
                    itemBuilder: (context, index) {
                      final d = alphabetData[index];
                      return Container(
                        color: d.color,
                        child: Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                width: 220,
                                height: 220,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.15),
                                      blurRadius: 12,
                                      offset: const Offset(0, 6),
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: Text(
                                    d.letter,
                                    style: TextStyle(
                                      fontSize: 120,
                                      fontWeight: FontWeight.w900,
                                      color: d.color,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 28),
                              Text(
                                d.emoji,
                                style: const TextStyle(fontSize: 90),
                              ),
                              const SizedBox(height: 16),
                              Text(
                                d.word,
                                style: const TextStyle(
                                  fontSize: 34,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 24, top: 8),
                  child: GestureDetector(
                    onTap: _speakCurrent,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 28, vertical: 14),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(30),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.1),
                            blurRadius: 6,
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.volume_up, color: data.color, size: 26),
                          const SizedBox(width: 8),
                          Text(
                            'Hear it again',
                            style: TextStyle(
                              color: data.color,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
            ConfettiWidget(
              confettiController: _confettiController,
              blastDirection: pi / 2,
              maxBlastForce: 8,
              minBlastForce: 3,
              emissionFrequency: 0.03,
              numberOfParticles: 16,
              gravity: 0.3,
            ),
          ],
        ),
      ),
    );
  }
}
