import 'package:flutter/material.dart';

class LetterData {
  final String letter;
  final String word;
  final String emoji;
  final Color color;

  const LetterData({
    required this.letter,
    required this.word,
    required this.emoji,
    required this.color,
  });
}

// A colorful palette that cycles through the alphabet so every letter
// screen feels distinct and playful for young children.
const List<Color> _palette = [
  Color(0xFFFF6B6B), // red
  Color(0xFFFFA94D), // orange
  Color(0xFFFFD43B), // yellow
  Color(0xFF69DB7C), // green
  Color(0xFF4DABF7), // blue
  Color(0xFF9775FA), // purple
  Color(0xFFF783AC), // pink
];

final List<LetterData> alphabetData = [
  LetterData(letter: 'A', word: 'Apple', emoji: '🍎', color: _palette[0]),
  LetterData(letter: 'B', word: 'Ball', emoji: '⚽', color: _palette[1]),
  LetterData(letter: 'C', word: 'Cat', emoji: '🐱', color: _palette[2]),
  LetterData(letter: 'D', word: 'Dog', emoji: '🐶', color: _palette[3]),
  LetterData(letter: 'E', word: 'Elephant', emoji: '🐘', color: _palette[4]),
  LetterData(letter: 'F', word: 'Fish', emoji: '🐟', color: _palette[5]),
  LetterData(letter: 'G', word: 'Grapes', emoji: '🍇', color: _palette[6]),
  LetterData(letter: 'H', word: 'Hat', emoji: '🎩', color: _palette[0]),
  LetterData(letter: 'I', word: 'Ice Cream', emoji: '🍦', color: _palette[1]),
  LetterData(letter: 'J', word: 'Juice', emoji: '🧃', color: _palette[2]),
  LetterData(letter: 'K', word: 'Kite', emoji: '🪁', color: _palette[3]),
  LetterData(letter: 'L', word: 'Lion', emoji: '🦁', color: _palette[4]),
  LetterData(letter: 'M', word: 'Moon', emoji: '🌙', color: _palette[5]),
  LetterData(letter: 'N', word: 'Nest', emoji: '🪺', color: _palette[6]),
  LetterData(letter: 'O', word: 'Orange', emoji: '🍊', color: _palette[0]),
  LetterData(letter: 'P', word: 'Parrot', emoji: '🦜', color: _palette[1]),
  LetterData(letter: 'Q', word: 'Queen', emoji: '👸', color: _palette[2]),
  LetterData(letter: 'R', word: 'Rabbit', emoji: '🐰', color: _palette[3]),
  LetterData(letter: 'S', word: 'Sun', emoji: '☀️', color: _palette[4]),
  LetterData(letter: 'T', word: 'Tiger', emoji: '🐯', color: _palette[5]),
  LetterData(letter: 'U', word: 'Umbrella', emoji: '☂️', color: _palette[6]),
  LetterData(letter: 'V', word: 'Violin', emoji: '🎻', color: _palette[0]),
  LetterData(letter: 'W', word: 'Watermelon', emoji: '🍉', color: _palette[1]),
  LetterData(letter: 'X', word: 'X-ray', emoji: '🩻', color: _palette[2]),
  LetterData(letter: 'Y', word: 'Yo-yo', emoji: '🪀', color: _palette[3]),
  LetterData(letter: 'Z', word: 'Zebra', emoji: '🦓', color: _palette[4]),
];
