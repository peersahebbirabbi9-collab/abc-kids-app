import 'package:flutter/material.dart';
import '../models/letter_data.dart';

class LetterCard extends StatelessWidget {
  final LetterData data;
  final VoidCallback onTap;
  final bool isLearned;

  const LetterCard({
    super.key,
    required this.data,
    required this.onTap,
    this.isLearned = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        decoration: BoxDecoration(
          color: data.color,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: data.color.withOpacity(0.4),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
          border: isLearned
              ? Border.all(color: Colors.white, width: 3)
              : null,
        ),
        child: Stack(
          children: [
            Center(
              child: Text(
                data.letter,
                style: const TextStyle(
                  fontSize: 42,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                ),
              ),
            ),
            if (isLearned)
              const Positioned(
                top: 6,
                right: 6,
                child: Icon(Icons.star, color: Colors.white, size: 18),
              ),
          ],
        ),
      ),
    );
  }
}
