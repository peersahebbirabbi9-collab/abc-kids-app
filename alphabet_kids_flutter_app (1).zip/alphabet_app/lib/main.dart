import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const AlphabetKidsApp());
}

class AlphabetKidsApp extends StatelessWidget {
  const AlphabetKidsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ABC Kids - Learn Alphabet',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Baloo',
        colorSchemeSeed: const Color(0xFF4DABF7),
        scaffoldBackgroundColor: const Color(0xFFFFF9EE),
      ),
      home: const HomeScreen(),
    );
  }
}
